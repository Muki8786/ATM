package sdk.optionMenu;

import sdk.StartAtm;
import main.global.Logout;
import sdk.UI.IAdminUI;
import sdk.UI.ICashDispenser;
import sdk.UI.IDepositSlot;
import sdk.adminTransactions.EmptyDepositSlot;
import sdk.adminTransactions.FillDispenser;

import static sdk.GlobalConfigChoice.configChoice;

public class AdminOptionMenu {
    private final String atmName;
    private IAdminUI adminUI;
    private ICashDispenser cashDispenser;
    private IDepositSlot depositSlot;

    public AdminOptionMenu(IAdminUI adminUI , ICashDispenser cashDispenser , IDepositSlot depositSlot , String atmName)
    {
        this.adminUI = adminUI;
        this.cashDispenser = cashDispenser;
        this.depositSlot = depositSlot;
        this.atmName = atmName;
    }

    public void createAdminMenu(int accountNumber)
    {
        int choice = adminUI.getAdminMenuInput();
        switch (choice)
        {
            case 0 :
            case -2:
                Logout.logout();
                StartAtm.restart();
                break;
            case 1 :
                new EmptyDepositSlot(adminUI,depositSlot,atmName,true).emptyDepositSlot(accountNumber);
                break;
            case 2 :
                new FillDispenser(adminUI,cashDispenser,depositSlot,atmName).fillCashDispenser(accountNumber);
                break;
            default:
            {
                if(configChoice!=1) {
                    adminUI.printInvalidInput();
                    Logout.logout();
                    StartAtm.restart();
                }
                else
                {
                    adminUI.printInvalidInput();
                    createAdminMenu(accountNumber);
                }
            }
        }
    }
}
