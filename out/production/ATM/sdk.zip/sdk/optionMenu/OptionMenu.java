package sdk.optionMenu;

import sdk.StartAtm;
import main.global.Logout;
import sdk.UI.*;
import sdk.transactions.*;

import static sdk.GlobalConfigChoice.configChoice;

public class OptionMenu {

    private IBalanceInquiryUI balanceInquiryUI;
    private IChangePinUI changePinUI;
    private IDepositUI depositUI;
    private IFastCashUI fastCashUI;
    private IFundTransferUI fundTransferUI;
    private IOptionMenuUI optionMenuUI;
    private IWithdrawUI withdrawUI;
    private ICashDispenser cashDispenser;
    private IDepositSlot depositSlot;

    public OptionMenu(IBalanceInquiryUI balanceInquiryUI, IChangePinUI changePinUI, IDepositUI depositUI, IFastCashUI fastCashUI, IFundTransferUI fundTransferUI, IOptionMenuUI optionMenuUI, IWithdrawUI withdrawUI, ICashDispenser cashDispenser, IDepositSlot depositSlot) {
        this.balanceInquiryUI = balanceInquiryUI;
        this.changePinUI = changePinUI;
        this.depositUI = depositUI;
        this.fastCashUI = fastCashUI;
        this.fundTransferUI = fundTransferUI;
        this.optionMenuUI = optionMenuUI;
        this.withdrawUI = withdrawUI;
        this.cashDispenser = cashDispenser;
        this.depositSlot = depositSlot;
    }



    public void createOptionMenu(int accountNumber)
    {
        int choice = optionMenuUI.optionMenu();
        switch (choice)
        {
            case 0 :
            case -2 :
                Logout.logout();
                StartAtm.restart();
                break;
            case 1 :
                new BalanceInquiry(balanceInquiryUI).balanceInquiry(accountNumber);
                break;
            case 2 :
                new Withdrawal(withdrawUI,cashDispenser,accountNumber).withdraw();
                break;
            case 3 :
                new FastCash(fastCashUI,withdrawUI ,cashDispenser ,accountNumber).fastCash();
                break;
            case 4 :
                new Deposit(depositUI,depositSlot,accountNumber).deposit();
                break;
            case 5 :
                new ChangePin(changePinUI,accountNumber).changeUserPin();
                break;
            case 6 :
                new FundTransfer(fundTransferUI,depositUI,depositSlot,accountNumber).fundTransfer();
                break;
            default:
            {
                if(configChoice!=1) {
                    optionMenuUI.printInvalidInput();
                    Logout.logout();
                    StartAtm.restart();
                }
                else
                {
                    optionMenuUI.printInvalidInput();
                    createOptionMenu(accountNumber);
                }
            }

        }
    }
}
