package sdk;

public class GlobalConfigChoice {
    public static final int configChoice = 1;
}
