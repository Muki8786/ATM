package sdk.transactions;

import sdk.Atm;
import sdk.StartAtm;
import sdk.UI.IBalanceInquiryUI;

import static sdk.GlobalConfigChoice.configChoice;
import static main.global.Logout.logout;

public class BalanceInquiry extends GlobalDatabase {

    private IBalanceInquiryUI balanceInquiryUI;

    public BalanceInquiry(IBalanceInquiryUI balanceInquiryUI)
    {
        this.balanceInquiryUI = balanceInquiryUI;
    }

    public void balanceInquiry(int accountNumber) {

        float balance = GlobalDatabase.accountsDatabase.getAccount(accountNumber).getBalance();
        balanceInquiryUI.printBalance(balance);
        if(configChoice == 1)
        {
            Atm.createOptionMenu(accountNumber);
        }
        else
        {
            logout();
            StartAtm.restart();
        }
    }
}
