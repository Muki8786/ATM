package sdk.transactions;


import sdk.accounts.AccountsDatabase;

public class GlobalDatabase {
    protected static AccountsDatabase accountsDatabase = new AccountsDatabase();
}
