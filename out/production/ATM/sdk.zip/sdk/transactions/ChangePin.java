package sdk.transactions;

import sdk.Atm;
import sdk.StartAtm;
import sdk.UI.IChangePinUI;
import sdk.accounts.Account;


import static sdk.GlobalConfigChoice.configChoice;
import static main.global.Logout.logout;

public class ChangePin {


    private final int accountNumber;
    private IChangePinUI changePinUI;


    public ChangePin(IChangePinUI changePinUI ,int accountNumber)
    {
        this.changePinUI = changePinUI;
        this.accountNumber = accountNumber;
    }

    private boolean verifyOldPin(int newPin, int oldPin)
    {
        if(newPin == oldPin)
        {
            return false;
        }
        else
        {
            return true;
        }

    }

    public void changeUserPin()
    {
        //ChangePinUI changePinUI = getChangePinUIInstance();
        Account account = GlobalDatabase.accountsDatabase.getAccount(accountNumber);
        int oldPin = account.getPin();
        int newPin = changePinUI.getNewPin();


        if(verifyOldPin(oldPin, newPin))
        {
            account.setPin(newPin);
            changePinUI.printSuccess(true);
        }
        else{
            changePinUI.printSuccess(false);
        }

        if(configChoice == 1)
        {
            Atm.createOptionMenu(accountNumber);
        }
        else
        {
            logout();
            StartAtm.restart();
        }
    }
}
