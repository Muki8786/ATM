package sdk.transactions;


import main.global.Logout;
import sdk.StartAtm;
import sdk.UI.ICashDispenser;
import sdk.UI.IFastCashUI;
import sdk.UI.IWithdrawUI;


import static sdk.GlobalConfigChoice.configChoice;

public class FastCash {
    private int accountNumber;
    private IFastCashUI fastCashUI;
    private IWithdrawUI withdrawUI;
    private ICashDispenser cashDispenser;

    public FastCash(IFastCashUI fastCashUI , IWithdrawUI withdrawUI, ICashDispenser cashDispenser, int accountNumber)
    {
        this.fastCashUI = fastCashUI;
        this.accountNumber = accountNumber;
        this.withdrawUI = withdrawUI;
        this.cashDispenser = cashDispenser;
    }

    public void fastCash()
    {
        //FastCashUI fastCashUI = new FastCashUI();
        int amount = 0;

        int choice = fastCashUI.getFastCashMenuChoice();
        switch (choice)
        {
            case 0 :
            case -2 :
                Logout.logout();
                StartAtm.restart();
                break;
            case 1 :
                amount = 500;
                break;
            case 2 :
                amount = 1000;
                break;
            case 3 :
                amount = 5000;
                break;
            case 4 :
                amount = 10000;
                break;
            default:
            {
                if (configChoice != 1)
                {
                    fastCashUI.printInvalidInput();
                    Logout.logout();
                    StartAtm.restart();
                }
                else
                {
                    fastCashUI.printInvalidInput();
                    fastCash();
                }
            }
        }

        if(amount>0)
        {
            new Withdrawal(withdrawUI ,cashDispenser ,accountNumber,amount).withdraw();
        }
    }
}
