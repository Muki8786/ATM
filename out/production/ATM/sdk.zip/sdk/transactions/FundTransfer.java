package sdk.transactions;


import sdk.Atm;
import sdk.StartAtm;
import sdk.UI.IDepositSlot;
import sdk.UI.IDepositUI;
import sdk.UI.IFundTransferUI;

import static sdk.GlobalConfigChoice.configChoice;
import static main.global.Logout.logout;
import static sdk.transactions.GlobalDatabase.accountsDatabase;


public class FundTransfer {
    private int accountNumber;
    private IFundTransferUI fundTransferUI;
    private IDepositUI depositUI;
    private IDepositSlot depositSlot;

    public FundTransfer(IFundTransferUI fundTransferUI , IDepositUI depositUI , IDepositSlot depositSlot ,int accountNumber)
    {
        this.fundTransferUI = fundTransferUI;
        this.depositUI = depositUI;
        this.depositSlot = depositSlot;
        this.accountNumber = accountNumber;
    }


    public void fundTransfer()
    {
        //FundTransferUI fundTransferUI = new FundTransferUI();

        int receiverAccountNumber =0;
        receiverAccountNumber = fundTransferUI.inputAccountNumber();
        if(checkReceiver(receiverAccountNumber))
        {
            Deposit deposit = new Deposit(depositUI,depositSlot,receiverAccountNumber);

            deposit.deposit();

            fundTransferUI.printSuccess(deposit.fundTransferSuccess);
        }
        else
        {
            fundTransferUI.printNoAccountFound();
        }
        if(configChoice == 1)
        {
            Atm.createOptionMenu(accountNumber);
        }
        else
        {
            logout();
            StartAtm.restart();
        }
    }

    public boolean checkReceiver(int receiverAccountNumber)
    {
        return accountsDatabase.accountCheck(receiverAccountNumber);
    }
}
