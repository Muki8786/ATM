package sdk.UI;

public interface IBalanceInquiryUI {
    void printBalance(float balance);
}
