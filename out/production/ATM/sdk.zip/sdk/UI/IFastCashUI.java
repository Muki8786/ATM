package sdk.UI;

public interface IFastCashUI {
    int getFastCashMenuChoice();

    void printInvalidInput();
}
