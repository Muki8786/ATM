package sdk.UI;

public interface IOptionMenuUI {
    int optionMenu();

    void printInvalidInput();
}
