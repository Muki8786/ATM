package sdk.UI;

public interface ILoginUI {
    void login(boolean allow, String name);

    int inputAccountNumber();

    int inputPin();
}
