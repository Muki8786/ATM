package sdk.UI;

public interface IChangePinUI {
    void printSuccess(boolean allow);

    int getNewPin();
}
