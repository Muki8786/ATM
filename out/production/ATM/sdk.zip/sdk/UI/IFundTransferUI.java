package sdk.UI;

public interface IFundTransferUI {
    void printNoAccountFound();

    void printSuccess(boolean value);

    int inputAccountNumber();
}
